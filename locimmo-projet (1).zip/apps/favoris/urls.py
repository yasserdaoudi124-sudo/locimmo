from django.urls import path
from . import views

app_name = 'favoris'

urlpatterns = [
    path('ajouter/<int:annonce_id>/', views.ajouter_favori, name='ajouter'),
    path('retirer/<int:annonce_id>/', views.retirer_favori, name='retirer'),
    path('mes-favoris/', views.mes_favoris, name='mes_favoris'),
    path('toggle/<int:annonce_id>/', views.toggle_favori, name='toggle'),
]
