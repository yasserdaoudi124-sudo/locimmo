from django.db import models
from django.conf import settings

class Favori(models.Model):
    utilisateur = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='favoris',
        limit_choices_to={'role': 'visiteur'}
    )
    annonce = models.ForeignKey(
        'annonces.Annonce',
        on_delete=models.CASCADE,
        related_name='favoris'
    )
    date_ajout = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Favori'
        verbose_name_plural = 'Favoris'
        unique_together = ['utilisateur', 'annonce']
        ordering = ['-date_ajout']

    def __str__(self):
        return f"{self.utilisateur} - {self.annonce.titre}"
