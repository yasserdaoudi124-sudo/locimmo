from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from .models import Favori
from apps.annonces.models import Annonce

@login_required
def ajouter_favori(request, annonce_id):
    annonce = get_object_or_404(Annonce, pk=annonce_id, statut='active')

    if request.user.est_proprietaire():
        messages.error(request, 'Les propriétaires ne peuvent pas ajouter de favoris.')
        return redirect('annonces:detail', pk=annonce_id)

    favori, created = Favori.objects.get_or_create(utilisateur=request.user, annonce=annonce)

    if created:
        messages.success(request, 'Annonce ajoutée à vos favoris !')
    else:
        messages.info(request, 'Cette annonce est déjà dans vos favoris.')

    return redirect('annonces:detail', pk=annonce_id)

@login_required
def retirer_favori(request, annonce_id):
    annonce = get_object_or_404(Annonce, pk=annonce_id)
    Favori.objects.filter(utilisateur=request.user, annonce=annonce).delete()
    messages.success(request, 'Annonce retirée de vos favoris.')
    return redirect('favoris:mes_favoris')

@login_required
def mes_favoris(request):
    if request.user.est_proprietaire():
        messages.error(request, 'Accès réservé aux visiteurs.')
        return redirect('annonces:accueil')

    favoris = Favori.objects.filter(utilisateur=request.user).select_related('annonce__type_bien')

    context = {
        'favoris': favoris,
    }
    return render(request, 'favoris/mes_favoris.html', context)

@login_required
def toggle_favori(request, annonce_id):
    if request.method == 'POST':
        annonce = get_object_or_404(Annonce, pk=annonce_id)
        favori = Favori.objects.filter(utilisateur=request.user, annonce=annonce)

        if favori.exists():
            favori.delete()
            return JsonResponse({'status': 'removed', 'message': 'Retiré des favoris'})
        else:
            Favori.objects.create(utilisateur=request.user, annonce=annonce)
            return JsonResponse({'status': 'added', 'message': 'Ajouté aux favoris'})

    return JsonResponse({'error': 'Méthode non autorisée'}, status=405)
