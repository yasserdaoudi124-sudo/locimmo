from django.contrib.auth.models import AbstractUser
from django.db import models

class Utilisateur(AbstractUser):
    ROLE_CHOICES = [
        ('proprietaire', 'Propriétaire'),
        ('visiteur', 'Visiteur'),
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='visiteur')
    telephone = models.CharField(max_length=20, blank=True)
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)
    date_naissance = models.DateField(blank=True, null=True)
    adresse = models.CharField(max_length=255, blank=True)
    ville = models.CharField(max_length=100, blank=True)

    class Meta:
        verbose_name = 'Utilisateur'
        verbose_name_plural = 'Utilisateurs'

    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.role})"

    def est_proprietaire(self):
        return self.role == 'proprietaire'

    def est_visiteur(self):
        return self.role == 'visiteur'

    def est_admin(self):
        return self.is_staff
