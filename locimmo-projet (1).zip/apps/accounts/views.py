from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import get_user_model
from .forms import InscriptionForm, ConnexionForm, ProfilForm

Utilisateur = get_user_model()

def inscription(request):
    if request.user.is_authenticated:
        return redirect('annonces:accueil')

    if request.method == 'POST':
        form = InscriptionForm(request.POST, request.FILES)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, f'Bienvenue {user.first_name} ! Votre compte a été créé avec succès.')
            return redirect('annonces:accueil')
    else:
        form = InscriptionForm()

    return render(request, 'accounts/inscription.html', {'form': form})

def connexion(request):
    if request.user.is_authenticated:
        return redirect('annonces:accueil')

    if request.method == 'POST':
        form = ConnexionForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, f'Bon retour, {user.first_name} !')
            next_url = request.GET.get('next', 'annonces:accueil')
            return redirect(next_url)
        else:
            messages.error(request, 'Identifiants incorrects. Veuillez réessayer.')
    else:
        form = ConnexionForm()

    return render(request, 'accounts/connexion.html', {'form': form})

@login_required
def deconnexion(request):
    logout(request)
    messages.info(request, 'Vous avez été déconnecté.')
    return redirect('annonces:accueil')

@login_required
def profil(request):
    if request.method == 'POST':
        form = ProfilForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Votre profil a été mis à jour avec succès.')
            return redirect('accounts:profil')
    else:
        form = ProfilForm(instance=request.user)

    return render(request, 'accounts/profil.html', {'form': form})
