from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import Utilisateur

@admin.register(Utilisateur)
class UtilisateurAdmin(UserAdmin):
    list_display = ['username', 'first_name', 'last_name', 'email', 'role', 'telephone', 'is_active']
    list_filter = ['role', 'is_active', 'date_joined']
    search_fields = ['username', 'first_name', 'last_name', 'email']

    fieldsets = UserAdmin.fieldsets + (
        ('Informations LOCIMMO', {'fields': ('role', 'telephone', 'avatar', 'adresse', 'ville')}),
    )
