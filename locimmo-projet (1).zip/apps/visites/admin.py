from django.contrib import admin
from .models import DemandeVisite

@admin.register(DemandeVisite)
class DemandeVisiteAdmin(admin.ModelAdmin):
    list_display = ['annonce', 'visiteur', 'nom', 'date_visite', 'statut', 'date_creation']
    list_filter = ['statut', 'date_visite', 'date_creation']
    search_fields = ['nom', 'email', 'message', 'annonce__titre']
    date_hierarchy = 'date_creation'
