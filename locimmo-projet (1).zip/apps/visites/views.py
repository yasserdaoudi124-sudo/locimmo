from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.paginator import Paginator
from .models import DemandeVisite
from .forms import DemandeVisiteForm
from apps.annonces.models import Annonce

@login_required
def creer_demande(request, annonce_id):
    annonce = get_object_or_404(Annonce, pk=annonce_id, statut='active')

    if request.user.est_proprietaire():
        messages.error(request, 'Les propriétaires ne peuvent pas envoyer de demandes de visite.')
        return redirect('annonces:detail', pk=annonce_id)

    if request.method == 'POST':
        form = DemandeVisiteForm(request.POST)
        if form.is_valid():
            demande = form.save(commit=False)
            demande.annonce = annonce
            demande.visiteur = request.user
            demande.save()
            messages.success(request, 'Votre demande de visite a été envoyée avec succès !')
            return redirect('annonces:detail', pk=annonce_id)
    else:
        form = DemandeVisiteForm(initial={
            'nom': f"{request.user.first_name} {request.user.last_name}",
            'email': request.user.email,
            'telephone': request.user.telephone,
        })

    return render(request, 'visites/creer.html', {
        'form': form,
        'annonce': annonce
    })

@login_required
def mes_demandes(request):
    if request.user.est_proprietaire():
        messages.error(request, 'Accès réservé aux visiteurs.')
        return redirect('annonces:accueil')

    demandes = DemandeVisite.objects.filter(visiteur=request.user).select_related('annonce')

    context = {
        'demandes': demandes,
    }
    return render(request, 'visites/mes_demandes.html', context)

@login_required
def demandes_recues(request):
    if not request.user.est_proprietaire():
        messages.error(request, 'Accès réservé aux propriétaires.')
        return redirect('annonces:accueil')

    demandes = DemandeVisite.objects.filter(annonce__proprietaire=request.user).select_related('annonce', 'visiteur')

    context = {
        'demandes': demandes,
    }
    return render(request, 'visites/demandes_recues.html', context)

@login_required
def modifier_statut(request, pk):
    demande = get_object_or_404(DemandeVisite, pk=pk, annonce__proprietaire=request.user)

    if request.method == 'POST':
        nouveau_statut = request.POST.get('statut')
        if nouveau_statut in ['acceptee', 'refusee', 'annulee']:
            demande.statut = nouveau_statut
            demande.save()
            messages.success(request, f'Statut mis à jour : {demande.get_statut_display()}')

    return redirect('visites:demandes_recues')
