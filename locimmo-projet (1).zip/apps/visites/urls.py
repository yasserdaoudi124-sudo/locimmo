from django.urls import path
from . import views

app_name = 'visites'

urlpatterns = [
    path('creer/<int:annonce_id>/', views.creer_demande, name='creer'),
    path('mes-demandes/', views.mes_demandes, name='mes_demandes'),
    path('demandes-recues/', views.demandes_recues, name='demandes_recues'),
    path('modifier-statut/<int:pk>/', views.modifier_statut, name='modifier_statut'),
]
