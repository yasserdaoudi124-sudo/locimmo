from django.db import models
from django.conf import settings

class DemandeVisite(models.Model):
    STATUT_CHOICES = [
        ('en_attente', 'En attente'),
        ('acceptee', 'Acceptée'),
        ('refusee', 'Refusée'),
        ('annulee', 'Annulée'),
    ]

    annonce = models.ForeignKey(
        'annonces.Annonce',
        on_delete=models.CASCADE,
        related_name='demandes_visite'
    )
    visiteur = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='demandes_visite',
        limit_choices_to={'role': 'visiteur'}
    )
    nom = models.CharField(max_length=100)
    email = models.EmailField()
    telephone = models.CharField(max_length=20)
    message = models.TextField()
    date_visite = models.DateField()
    statut = models.CharField(max_length=20, choices=STATUT_CHOICES, default='en_attente')
    date_creation = models.DateTimeField(auto_now_add=True)
    date_modification = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Demande de visite'
        verbose_name_plural = 'Demandes de visite'
        ordering = ['-date_creation']

    def __str__(self):
        return f"Visite de {self.nom} pour {self.annonce.titre}"
