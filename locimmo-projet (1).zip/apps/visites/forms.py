from django import forms
from .models import DemandeVisite

class DemandeVisiteForm(forms.ModelForm):
    class Meta:
        model = DemandeVisite
        fields = ['nom', 'email', 'telephone', 'message', 'date_visite']
        widgets = {
            'nom': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Votre nom complet'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Votre email'}),
            'telephone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Votre téléphone'}),
            'message': forms.Textarea(attrs={'class': 'form-control', 'rows': 4, 'placeholder': 'Votre message...'}),
            'date_visite': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
        }
