from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from django.http import JsonResponse
from django.core.paginator import Paginator
from django.views.decorators.http import require_POST
from .models import Annonce, Photo, TypeBien
from .forms import AnnonceForm, PhotoFormSet, RechercheForm
from apps.visites.models import DemandeVisite

def accueil(request):
    annonces = Annonce.objects.filter(statut='active').select_related('type_bien', 'proprietaire')[:6]
    types = TypeBien.objects.all()
    total_annonces = Annonce.objects.filter(statut='active').count()
    total_proprietaires = Annonce.objects.filter(statut='active').values('proprietaire').distinct().count()

    context = {
        'annonces': annonces,
        'types': types,
        'total_annonces': total_annonces,
        'total_proprietaires': total_proprietaires,
    }
    return render(request, 'annonces/accueil.html', context)

def recherche(request):
    form = RechercheForm(request.GET or None)
    annonces = Annonce.objects.filter(statut='active').select_related('type_bien')

    if form.is_valid():
        data = form.cleaned_data

        if data.get('q'):
            annonces = annonces.filter(
                Q(titre__icontains=data['q']) |
                Q(description__icontains=data['q']) |
                Q(ville__icontains=data['q']) |
                Q(adresse__icontains=data['q'])
            )

        if data.get('type_bien'):
            annonces = annonces.filter(type_bien=data['type_bien'])

        if data.get('prix_min'):
            annonces = annonces.filter(prix__gte=data['prix_min'])
        if data.get('prix_max'):
            annonces = annonces.filter(prix__lte=data['prix_max'])

        if data.get('surface_min'):
            annonces = annonces.filter(surface__gte=data['surface_min'])
        if data.get('surface_max'):
            annonces = annonces.filter(surface__lte=data['surface_max'])

        if data.get('pieces'):
            annonces = annonces.filter(pieces__gte=data['pieces'])
        if data.get('chambres'):
            annonces = annonces.filter(chambres__gte=data['chambres'])

        if data.get('ville'):
            annonces = annonces.filter(ville__icontains=data['ville'])

    paginator = Paginator(annonces, 12)
    page = request.GET.get('page')
    annonces_page = paginator.get_page(page)

    context = {
        'form': form,
        'annonces': annonces_page,
        'types': TypeBien.objects.all(),
    }
    return render(request, 'annonces/recherche.html', context)

def carte(request):
    form = RechercheForm(request.GET or None)
    annonces = Annonce.objects.filter(statut='active').select_related('type_bien')

    if form.is_valid():
        data = form.cleaned_data
        if data.get('q'):
            annonces = annonces.filter(Q(ville__icontains=data['q']) | Q(titre__icontains=data['q']))
        if data.get('type_bien'):
            annonces = annonces.filter(type_bien=data['type_bien'])
        if data.get('prix_min'):
            annonces = annonces.filter(prix__gte=data['prix_min'])
        if data.get('prix_max'):
            annonces = annonces.filter(prix__lte=data['prix_max'])

    context = {
        'form': form,
        'annonces': annonces,
        'types': TypeBien.objects.all(),
    }
    return render(request, 'annonces/carte.html', context)

def detail(request, pk):
    annonce = get_object_or_404(Annonce, pk=pk)
    photos = annonce.photos.all()
    est_favori = False

    if request.user.is_authenticated and request.user.est_visiteur():
        est_favori = annonce.favoris.filter(utilisateur=request.user).exists()

    context = {
        'annonce': annonce,
        'photos': photos,
        'est_favori': est_favori,
    }
    return render(request, 'annonces/detail.html', context)

@login_required
def creer_annonce(request):
    if not request.user.est_proprietaire():
        messages.error(request, 'Seuls les propriétaires peuvent publier des annonces.')
        return redirect('annonces:accueil')

    if request.method == 'POST':
        form = AnnonceForm(request.POST)
        if form.is_valid():
            annonce = form.save(commit=False)
            annonce.proprietaire = request.user
            annonce.save()

            # Gestion des photos
            files = request.FILES.getlist('photos')
            for i, file in enumerate(files):
                Photo.objects.create(annonce=annonce, image=file, ordre=i)

            messages.success(request, 'Annonce publiée avec succès !')
            return redirect('annonces:detail', pk=annonce.pk)
    else:
        form = AnnonceForm()

    return render(request, 'annonces/creer.html', {'form': form})

@login_required
def modifier_annonce(request, pk):
    annonce = get_object_or_404(Annonce, pk=pk, proprietaire=request.user)

    if request.method == 'POST':
        form = AnnonceForm(request.POST, instance=annonce)
        if form.is_valid():
            form.save()

            files = request.FILES.getlist('photos')
            for i, file in enumerate(files):
                Photo.objects.create(annonce=annonce, image=file, ordre=annonce.photos.count() + i)

            messages.success(request, 'Annonce mise à jour avec succès !')
            return redirect('annonces:detail', pk=annonce.pk)
    else:
        form = AnnonceForm(instance=annonce)

    return render(request, 'annonces/modifier.html', {
        'form': form,
        'annonce': annonce,
        'photos': annonce.photos.all()
    })

@login_required
def supprimer_annonce(request, pk):
    annonce = get_object_or_404(Annonce, pk=pk, proprietaire=request.user)

    if request.method == 'POST':
        annonce.delete()
        messages.success(request, 'Annonce supprimée avec succès.')
        return redirect('annonces:mes_annonces')

    return render(request, 'annonces/confirmer_suppression.html', {'annonce': annonce})

@login_required
@require_POST
def toggle_statut(request, pk):
    annonce = get_object_or_404(Annonce, pk=pk, proprietaire=request.user)
    annonce.statut = 'inactive' if annonce.statut == 'active' else 'active'
    annonce.save()
    messages.success(request, f'Annonce {"activée" if annonce.statut == "active" else "désactivée"}.')
    return redirect('annonces:mes_annonces')

@login_required
def dashboard_proprietaire(request):
    if not request.user.est_proprietaire():
        messages.error(request, 'Accès réservé aux propriétaires.')
        return redirect('annonces:accueil')

    annonces = request.user.annonces.all()
    total_annonces = annonces.count()
    annonces_actives = annonces.filter(statut='active').count()
    annonces_inactives = total_annonces - annonces_actives

    visites = DemandeVisite.objects.filter(annonce__proprietaire=request.user)
    total_visites = visites.count()
    visites_en_attente = visites.filter(statut='en_attente').count()

    total_favoris = sum(a.favoris.count() for a in annonces)

    context = {
        'total_annonces': total_annonces,
        'annonces_actives': annonces_actives,
        'annonces_inactives': annonces_inactives,
        'total_visites': total_visites,
        'visites_en_attente': visites_en_attente,
        'total_favoris': total_favoris,
        'annonces_recentes': annonces[:5],
        'visites_recentes': visites[:5],
    }
    return render(request, 'annonces/dashboard.html', context)

@login_required
def mes_annonces(request):
    if not request.user.est_proprietaire():
        messages.error(request, 'Accès réservé aux propriétaires.')
        return redirect('annonces:accueil')

    annonces = request.user.annonces.all().select_related('type_bien')

    context = {
        'annonces': annonces,
    }
    return render(request, 'annonces/mes_annonces.html', context)

def api_annonces(request):
    annonces = Annonce.objects.filter(statut='active').select_related('type_bien')

    q = request.GET.get('q')
    type_bien = request.GET.get('type_bien')
    prix_min = request.GET.get('prix_min')
    prix_max = request.GET.get('prix_max')

    if q:
        annonces = annonces.filter(Q(ville__icontains=q) | Q(titre__icontains=q))
    if type_bien:
        annonces = annonces.filter(type_bien_id=type_bien)
    if prix_min:
        annonces = annonces.filter(prix__gte=prix_min)
    if prix_max:
        annonces = annonces.filter(prix__lte=prix_max)

    data = []
    for a in annonces:
        photo = a.photo_principale()
        data.append({
            'id': a.id,
            'titre': a.titre,
            'prix': float(a.prix),
            'ville': a.ville,
            'surface': a.surface,
            'pieces': a.pieces,
            'chambres': a.chambres,
            'latitude': float(a.latitude) if a.latitude else None,
            'longitude': float(a.longitude) if a.longitude else None,
            'type': a.type_bien.nom,
            'photo': photo,
            'url': a.get_absolute_url(),
        })

    return JsonResponse({'annonces': data})


def presentation(request):
    """Page de présentation du projet LOCIMMO"""
    return render(request, 'presentation.html')
