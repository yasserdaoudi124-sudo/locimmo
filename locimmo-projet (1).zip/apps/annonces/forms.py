from django import forms
from .models import Annonce, Photo, TypeBien

class AnnonceForm(forms.ModelForm):
    class Meta:
        model = Annonce
        fields = [
            'titre', 'description', 'type_bien', 'prix', 'surface',
            'pieces', 'chambres', 'salles_bain', 'adresse', 'ville',
            'code_postal', 'latitude', 'longitude', 'statut'
        ]
        widgets = {
            'titre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': "Titre de l'annonce"}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 5, 'placeholder': 'Description détaillée du bien...'}),
            'type_bien': forms.Select(attrs={'class': 'form-select'}),
            'prix': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Prix mensuel en DH'}),
            'surface': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Surface en m²'}),
            'pieces': forms.NumberInput(attrs={'class': 'form-control'}),
            'chambres': forms.NumberInput(attrs={'class': 'form-control'}),
            'salles_bain': forms.NumberInput(attrs={'class': 'form-control'}),
            'adresse': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Adresse complète'}),
            'ville': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ville'}),
            'code_postal': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Code postal'}),
            'latitude': forms.HiddenInput(),
            'longitude': forms.HiddenInput(),
            'statut': forms.Select(attrs={'class': 'form-select'}),
        }

class PhotoForm(forms.ModelForm):
    class Meta:
        model = Photo
        fields = ['image', 'ordre']
        widgets = {
            'image': forms.FileInput(attrs={'class': 'form-control', 'accept': 'image/*'}),
            'ordre': forms.NumberInput(attrs={'class': 'form-control'}),
        }

PhotoFormSet = forms.inlineformset_factory(
    Annonce, Photo,
    form=PhotoForm,
    extra=5,
    can_delete=True,
    max_num=10
)

class RechercheForm(forms.Form):
    q = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Rechercher par ville, titre...'
        })
    )
    type_bien = forms.ModelChoiceField(
        queryset=TypeBien.objects.all(),
        required=False,
        empty_label='Tous les types',
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    prix_min = forms.IntegerField(
        required=False,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Min'})
    )
    prix_max = forms.IntegerField(
        required=False,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Max'})
    )
    surface_min = forms.IntegerField(
        required=False,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Min m²'})
    )
    surface_max = forms.IntegerField(
        required=False,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Max m²'})
    )
    pieces = forms.IntegerField(
        required=False,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Pièces min'})
    )
    chambres = forms.IntegerField(
        required=False,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Chambres min'})
    )
    ville = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ville'})
    )
