from django.contrib import admin
from .models import TypeBien, Annonce, Photo

@admin.register(TypeBien)
class TypeBienAdmin(admin.ModelAdmin):
    list_display = ['nom', 'description']
    search_fields = ['nom']

class PhotoInline(admin.TabularInline):
    model = Photo
    extra = 1

@admin.register(Annonce)
class AnnonceAdmin(admin.ModelAdmin):
    list_display = ['titre', 'proprietaire', 'type_bien', 'prix', 'ville', 'statut', 'date_creation']
    list_filter = ['statut', 'type_bien', 'ville', 'date_creation']
    search_fields = ['titre', 'description', 'ville', 'adresse']
    inlines = [PhotoInline]
    date_hierarchy = 'date_creation'

@admin.register(Photo)
class PhotoAdmin(admin.ModelAdmin):
    list_display = ['annonce', 'ordre', 'date_upload']
    list_filter = ['date_upload']
