from django.db import models
from django.conf import settings
from django.urls import reverse

class TypeBien(models.Model):
    nom = models.CharField(max_length=50, unique=True)
    description = models.TextField(blank=True)
    icone = models.CharField(max_length=50, blank=True, help_text='Classe FontAwesome')

    class Meta:
        verbose_name = 'Type de bien'
        verbose_name_plural = 'Types de biens'
        ordering = ['nom']

    def __str__(self):
        return self.nom

class Annonce(models.Model):
    STATUT_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]

    proprietaire = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='annonces',
        limit_choices_to={'role': 'proprietaire'}
    )
    titre = models.CharField(max_length=200)
    description = models.TextField()
    type_bien = models.ForeignKey(TypeBien, on_delete=models.PROTECT, related_name='annonces')
    prix = models.DecimalField(max_digits=12, decimal_places=2)
    surface = models.PositiveIntegerField(help_text='Surface en m²')
    pieces = models.PositiveIntegerField(default=1, verbose_name='Nombre de pièces')
    chambres = models.PositiveIntegerField(default=1, verbose_name='Nombre de chambres')
    salles_bain = models.PositiveIntegerField(default=1, verbose_name='Salles de bain')

    adresse = models.CharField(max_length=255)
    ville = models.CharField(max_length=100)
    code_postal = models.CharField(max_length=20, blank=True)

    latitude = models.DecimalField(max_digits=10, decimal_places=8, blank=True, null=True)
    longitude = models.DecimalField(max_digits=11, decimal_places=8, blank=True, null=True)

    statut = models.CharField(max_length=20, choices=STATUT_CHOICES, default='active')

    date_creation = models.DateTimeField(auto_now_add=True)
    date_modification = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Annonce'
        verbose_name_plural = 'Annonces'
        ordering = ['-date_creation']

    def __str__(self):
        return f"{self.titre} - {self.ville} ({self.prix} DH)"

    def get_absolute_url(self):
        return reverse('annonces:detail', kwargs={'pk': self.pk})

    def photo_principale(self):
        photo = self.photos.first()
        return photo.image.url if photo else None

    def nombre_photos(self):
        return self.photos.count()

    def nombre_favoris(self):
        return self.favoris.count()

    def est_active(self):
        return self.statut == 'active'

class Photo(models.Model):
    annonce = models.ForeignKey(Annonce, on_delete=models.CASCADE, related_name='photos')
    image = models.ImageField(upload_to='annonces/%Y/%m/')
    ordre = models.PositiveIntegerField(default=0)
    date_upload = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Photo'
        verbose_name_plural = 'Photos'
        ordering = ['ordre']

    def __str__(self):
        return f"Photo {self.ordre} - {self.annonce.titre}"
