from django.urls import path
from . import views

app_name = 'annonces'

urlpatterns = [
    path('', views.accueil, name='accueil'),
    path('recherche/', views.recherche, name='recherche'),
    path('carte/', views.carte, name='carte'),
    path('annonce/<int:pk>/', views.detail, name='detail'),
    path('annonce/nouvelle/', views.creer_annonce, name='creer'),
    path('annonce/<int:pk>/modifier/', views.modifier_annonce, name='modifier'),
    path('annonce/<int:pk>/supprimer/', views.supprimer_annonce, name='supprimer'),
    path('annonce/<int:pk>/toggle-statut/', views.toggle_statut, name='toggle_statut'),
    path('dashboard/', views.dashboard_proprietaire, name='dashboard'),
    path('mes-annonces/', views.mes_annonces, name='mes_annonces'),
    path('api/annonces/', views.api_annonces, name='api_annonces'),
    path('presentation/', views.presentation, name='presentation'),
]
