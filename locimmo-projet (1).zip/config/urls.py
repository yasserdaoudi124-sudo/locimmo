"""
URL Configuration pour LOCIMMO
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('apps.annonces.urls')),
    path('accounts/', include('apps.accounts.urls')),
    path('visites/', include('apps.visites.urls')),
    path('favoris/', include('apps.favoris.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
