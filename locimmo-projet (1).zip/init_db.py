#!/usr/bin/env python
import os
import sys
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

django.setup()

from django.contrib.auth import get_user_model
from apps.annonces.models import TypeBien, Annonce

Utilisateur = get_user_model()

def creer_types_biens():
    types_data = [
        {'nom': 'Appartement', 'description': 'Appartement residentiel', 'icone': 'fa-building'},
        {'nom': 'Maison', 'description': 'Maison individuelle', 'icone': 'fa-home'},
        {'nom': 'Studio', 'description': 'Studio meuble ou non', 'icone': 'fa-bed'},
        {'nom': 'Villa', 'description': 'Villa de luxe', 'icone': 'fa-landmark'},
        {'nom': 'Duplex', 'description': 'Appartement duplex', 'icone': 'fa-building'},
        {'nom': 'Riad', 'description': 'Riad traditionnel', 'icone': 'fa-om'},
    ]
    for data in types_data:
        TypeBien.objects.get_or_create(nom=data['nom'], defaults=data)
    print("Types de biens crees")

def creer_utilisateurs():
    if not Utilisateur.objects.filter(username='proprietaire').exists():
        Utilisateur.objects.create_user(
            username='proprietaire',
            email='proprietaire@locimmo.ma',
            password='demo1234',
            first_name='Ahmed',
            last_name='Alami',
            role='proprietaire',
            telephone='0612345678',
            ville='Casablanca'
        )
        print("Proprietaire cree : proprietaire@locimmo.ma / demo1234")
    if not Utilisateur.objects.filter(username='visiteur').exists():
        Utilisateur.objects.create_user(
            username='visiteur',
            email='visiteur@locimmo.ma',
            password='demo1234',
            first_name='Sara',
            last_name='Benani',
            role='visiteur',
            telephone='0698765432',
            ville='Rabat'
        )
        print("Visiteur cree : visiteur@locimmo.ma / demo1234")

def creer_annonces_demo():
    proprietaire = Utilisateur.objects.get(username='proprietaire')
    appartement = TypeBien.objects.get(nom='Appartement')
    maison = TypeBien.objects.get(nom='Maison')
    studio = TypeBien.objects.get(nom='Studio')
    villa = TypeBien.objects.get(nom='Villa')
    duplex = TypeBien.objects.get(nom='Duplex')

    annonces_data = [
        {
            'titre': 'Bel appartement 2 chambres Maarif',
            'description': 'Superbe appartement lumineux situe au coeur du quartier Maarif. Entierement renove avec des materiaux de qualite.',
            'type_bien': appartement, 'prix': 6500, 'surface': 85, 'pieces': 3, 'chambres': 2, 'salles_bain': 1,
            'adresse': '45 Rue Ibn Sina', 'ville': 'Casablanca', 'code_postal': '20100',
            'latitude': 33.589886, 'longitude': -7.603869,
        },
        {
            'titre': 'Villa moderne avec piscine Bouskoura',
            'description': 'Magnifique villa contemporaine de 300m2 avec piscine privee et jardin paysager. 4 chambres, salon double.',
            'type_bien': villa, 'prix': 25000, 'surface': 300, 'pieces': 6, 'chambres': 4, 'salles_bain': 3,
            'adresse': 'Lotissement Les Orangers', 'ville': 'Bouskoura', 'code_postal': '27182',
            'latitude': 33.448900, 'longitude': -7.651700,
        },
        {
            'titre': 'Studio meuble centre ville',
            'description': 'Studio entierement meuble ideal pour etudiant ou jeune actif. Situe en plein centre ville.',
            'type_bien': studio, 'prix': 2800, 'surface': 35, 'pieces': 1, 'chambres': 1, 'salles_bain': 1,
            'adresse': '12 Avenue Mohammed V', 'ville': 'Casablanca', 'code_postal': '20000',
            'latitude': 33.593100, 'longitude': -7.619800,
        },
        {
            'titre': 'Maison familiale Hay Riad',
            'description': 'Belle maison familiale de 150m2 dans un quartier calme et residentiel. 3 chambres, salon, garage.',
            'type_bien': maison, 'prix': 9000, 'surface': 150, 'pieces': 5, 'chambres': 3, 'salles_bain': 2,
            'adresse': '78 Rue Oued Zem', 'ville': 'Rabat', 'code_postal': '10000',
            'latitude': 34.020882, 'longitude': -6.841650,
        },
        {
            'titre': 'Appartement luxe Anfa Place',
            'description': 'Appartement haut standing avec vue sur mer. Residence securisee avec piscine collective.',
            'type_bien': appartement, 'prix': 12000, 'surface': 120, 'pieces': 4, 'chambres': 2, 'salles_bain': 2,
            'adresse': 'Boulevard de la Corniche', 'ville': 'Casablanca', 'code_postal': '20050',
            'latitude': 33.598500, 'longitude': -7.665000,
        },
        {
            'titre': 'Duplex moderne Souissi',
            'description': 'Duplex contemporain de 180m2 avec terrasse privee. Quartier residentiel prestigieux.',
            'type_bien': duplex, 'prix': 15000, 'surface': 180, 'pieces': 5, 'chambres': 3, 'salles_bain': 2,
            'adresse': '15 Rue des Acacias', 'ville': 'Rabat', 'code_postal': '10100',
            'latitude': 33.966800, 'longitude': -6.827600,
        },
    ]

    for data in annonces_data:
        annonce, created = Annonce.objects.get_or_create(
            titre=data['titre'],
            defaults={**data, 'proprietaire': proprietaire}
        )
        if created:
            print(f"  Annonce creee : {annonce.titre}")
    print("Annonces de demonstration creees")

def main():
    print("=" * 60)
    print("  INITIALISATION DE LOCIMMO")
    print("=" * 60)
    creer_types_biens()
    creer_utilisateurs()
    creer_annonces_demo()
    print("=" * 60)
    print("  INITIALISATION TERMINEE")
    print("=" * 60)
    print("\nComptes de demonstration :")
    print("  Proprietaire : proprietaire@locimmo.ma / demo1234")
    print("  Visiteur     : visiteur@locimmo.ma / demo1234")
    print("\nLancer le serveur : python manage.py runserver")
    print("=" * 60)

if __name__ == '__main__':
    main()
