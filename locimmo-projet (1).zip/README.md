# LOCIMMO - Système de Location Immobilière

Projet de Fin d'Études - EMSI Casablanca
Filière : Ingénierie Informatique et Réseaux
Année Universitaire : 2025-2026

## Description

LOCIMMO est une application web moderne de location immobilière développée avec Django et Python. Elle permet aux propriétaires de publier et gérer leurs annonces, et aux visiteurs de rechercher des biens avec des filtres avancés et une carte interactive.

## Fonctionnalités

- **Authentification multi-rôles** : Propriétaire / Visiteur
- **Gestion des annonces** : CRUD complet avec photos multiples
- **Moteur de recherche avancé** : Filtres multi-critères
- **Carte interactive** : Leaflet.js + OpenStreetMap
- **Système de favoris** : Sauvegarde des annonces préférées
- **Demandes de visite** : Formulaire de contact traçable
- **Tableau de bord propriétaire** : Statistiques et suivi
- **Interface responsive** : Bootstrap 5

## Technologies

- **Backend** : Python 3.x, Django 4.x
- **Base de données** : SQLite (développement)
- **Frontend** : HTML5, CSS3, JavaScript ES6+
- **Cartographie** : Leaflet.js + OpenStreetMap
- **UI Framework** : Bootstrap 5
- **Images** : Pillow

## Installation

```bash
# Cloner le projet
cd locimmo

# Installer les dépendances
pip install -r requirements.txt

# Appliquer les migrations
python manage.py migrate

# Créer un superutilisateur
python manage.py createsuperuser

# Lancer le serveur
python manage.py runserver
```

## Structure du Projet

```
locimmo/
├── config/              # Configuration Django
├── apps/
│   ├── accounts/        # Authentification & profils
│   ├── annonces/        # Gestion des biens
│   ├── visites/         # Demandes de visite
│   └── favoris/         # Système de favoris
├── templates/           # Templates HTML
├── static/              # CSS, JS, images
└── media/               # Photos uploadées
```

## Auteur

[Votre Nom] - EMSI Casablanca
